﻿
namespace Urok1.DAL
{
        public class Student
        {
            public int Id { get; set; }

            public string Name { get; set; }

            public int Age { get; set; }

            public string Adres { get; set; }

            public string Gmail { get; set; }

            public int Year { get; set; }

        }
}
